/**
 * ملف ربط النماذج (Models Index)
 * يربط جميع النماذج ويحدد العلاقات بينها
 */

const sequelize = require('../config/database');

// استيراد جميع النماذج
const User = require('./User');
const Subscription = require('./Subscription');
const SubscriptionPlan = require('./SubscriptionPlan');
const PaymentRequest = require('./PaymentRequest');
const WhatsAppBot = require('./WhatsAppBot');
const WhatsAppSession = require('./WhatsAppSession');
const TelegramBot = require('./TelegramBot');
const TelegramSubscriber = require('./TelegramSubscriber');
const ClientWebsite = require('./ClientWebsite');
const CatalogItem = require('./CatalogItem');
const AISetting = require('./AISetting');
const MessageUsage = require('./MessageUsage');
const SupportTicket = require('./SupportTicket');
const PasswordResetRequest = require('./PasswordResetRequest');
const Notification = require('./Notification');
const DeleteEditTrackingSetting = require('./DeleteEditTrackingSetting');
const AdminLog = require('./AdminLog');

// ============================================================
// تعريف العلاقات بين الجداول (Associations)
// ============================================================

// ==================== User ====================
// المستخدم -> الاشتراكات
User.hasMany(Subscription, { foreignKey: 'user_id', as: 'subscriptions' });
Subscription.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// المستخدم -> طلبات الدفع
User.hasMany(PaymentRequest, { foreignKey: 'user_id', as: 'payments' });
PaymentRequest.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// المستخدم -> بوتات واتساب
User.hasMany(WhatsAppBot, { foreignKey: 'user_id', as: 'whatsapp_bots' });
WhatsAppBot.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// المستخدم -> بوتات تيليجرام
User.hasMany(TelegramBot, { foreignKey: 'user_id', as: 'telegram_bots' });
TelegramBot.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// المستخدم -> مواقع العملاء
User.hasMany(ClientWebsite, { foreignKey: 'user_id', as: 'websites' });
ClientWebsite.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// المستخدم -> كتالوج المؤسسة
User.hasMany(CatalogItem, { foreignKey: 'user_id', as: 'catalog_items' });
CatalogItem.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// المستخدم -> إعدادات الذكاء الاصطناعي
User.hasOne(AISetting, { foreignKey: 'user_id', as: 'ai_settings' });
AISetting.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// المستخدم -> استخدام الرسائل
User.hasMany(MessageUsage, { foreignKey: 'user_id', as: 'message_usage' });
MessageUsage.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// المستخدم -> تذاكر الدعم
User.hasMany(SupportTicket, { foreignKey: 'user_id', as: 'support_tickets' });
SupportTicket.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// المستخدم -> طلبات استرداد الحساب
User.hasMany(PasswordResetRequest, { foreignKey: 'user_id', as: 'reset_requests' });
PasswordResetRequest.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// المستخدم -> الإشعارات
User.hasMany(Notification, { foreignKey: 'user_id', as: 'notifications' });
Notification.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// المستخدم -> سجل المشرفين (للمشرفين فقط)
User.hasMany(AdminLog, { foreignKey: 'admin_id', as: 'admin_logs' });
AdminLog.belongsTo(User, { foreignKey: 'admin_id', as: 'admin' });

// ==================== Subscription ====================
// الاشتراك -> خطة الاشتراك
Subscription.belongsTo(SubscriptionPlan, { foreignKey: 'plan_id', as: 'plan' });
SubscriptionPlan.hasMany(Subscription, { foreignKey: 'plan_id', as: 'subscriptions' });

// ==================== WhatsAppBot ====================
// بوت واتساب -> جلسات واتساب
WhatsAppBot.hasMany(WhatsAppSession, { foreignKey: 'bot_id', as: 'sessions' });
WhatsAppSession.belongsTo(WhatsAppBot, { foreignKey: 'bot_id', as: 'bot' });

// بوت واتساب -> إعدادات مراقبة التعديل والحذف
WhatsAppBot.hasOne(DeleteEditTrackingSetting, { foreignKey: 'bot_id', as: 'tracking_settings' });
DeleteEditTrackingSetting.belongsTo(WhatsAppBot, { foreignKey: 'bot_id', as: 'bot' });

// ==================== TelegramBot ====================
// بوت تيليجرام -> المشتركين
TelegramBot.hasMany(TelegramSubscriber, { foreignKey: 'bot_id', as: 'subscribers' });
TelegramSubscriber.belongsTo(TelegramBot, { foreignKey: 'bot_id', as: 'bot' });

// ==================== PaymentRequest ====================
// طلب الدفع -> الاشتراك (اختياري)
PaymentRequest.belongsTo(Subscription, { foreignKey: 'subscription_id', as: 'subscription' });
Subscription.hasOne(PaymentRequest, { foreignKey: 'subscription_id', as: 'payment' });

// ============================================================
// مزامنة النماذج مع قاعدة البيانات (للتطوير فقط)
// ============================================================

const syncModels = async (force = false) => {
    try {
        if (force) {
            console.log('⚠️ Force sync: Dropping all tables...');
        }
        
        await sequelize.sync({ alter: !force, force });
        console.log('✅ All models synchronized with database');
    } catch (error) {
        console.error('❌ Database sync error:', error);
        throw error;
    }
};

// ============================================================
// تصدير جميع النماذج والعلاقات
// ============================================================

module.exports = {
    sequelize,
    syncModels,
    
    // النماذج
    User,
    Subscription,
    SubscriptionPlan,
    PaymentRequest,
    WhatsAppBot,
    WhatsAppSession,
    TelegramBot,
    TelegramSubscriber,
    ClientWebsite,
    CatalogItem,
    AISetting,
    MessageUsage,
    SupportTicket,
    PasswordResetRequest,
    Notification,
    DeleteEditTrackingSetting,
    AdminLog
};