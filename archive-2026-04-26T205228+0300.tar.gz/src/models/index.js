const sequelize = require('../config/database');

const User = require('./User');
const Subscription = require('./Subscription');
const SubscriptionPlan = require('./SubscriptionPlan');
const PaymentRequest = require('./PaymentRequest');
const WhatsAppBot = require('./WhatsAppBot');
const WhatsAppSession = require('./WhatsAppSession');
const TelegramBot = require('./TelegramBot');
const TelegramSubscriber = require('./TelegramSubscriber');
const ClientWebsite = require('./ClientWebsite');
const CatalogItem = require('./CatalogItem');
const AISetting = require('./AISetting');
const MessageUsage = require('./MessageUsage');
const SupportTicket = require('./SupportTicket');
const PasswordResetRequest = require('./PasswordResetRequest');
const Notification = require('./Notification');
const DeleteEditTrackingSetting = require('./DeleteEditTrackingSetting');
const AdminLog = require('./AdminLog');

// ============================================================
// User hasMany relations
// ============================================================
User.hasMany(Subscription, { foreignKey: 'user_id' });
User.hasMany(PaymentRequest, { foreignKey: 'user_id' });
User.hasMany(WhatsAppBot, { foreignKey: 'user_id' });
User.hasMany(TelegramBot, { foreignKey: 'user_id' });
User.hasMany(ClientWebsite, { foreignKey: 'user_id' });
User.hasMany(CatalogItem, { foreignKey: 'user_id' });
User.hasOne(AISetting, { foreignKey: 'user_id' });
User.hasMany(MessageUsage, { foreignKey: 'user_id' });
User.hasMany(SupportTicket, { foreignKey: 'user_id' });
User.hasMany(PasswordResetRequest, { foreignKey: 'user_id' });
User.hasMany(Notification, { foreignKey: 'user_id' });
User.hasMany(AdminLog, { foreignKey: 'admin_id' });

// ============================================================
// User belongsTo relations (بدون استخدام as متكرر)
// ============================================================
Subscription.belongsTo(User, { foreignKey: 'user_id' });
PaymentRequest.belongsTo(User, { foreignKey: 'user_id' });
WhatsAppBot.belongsTo(User, { foreignKey: 'user_id' });
TelegramBot.belongsTo(User, { foreignKey: 'user_id' });
ClientWebsite.belongsTo(User, { foreignKey: 'user_id' });
CatalogItem.belongsTo(User, { foreignKey: 'user_id' });
AISetting.belongsTo(User, { foreignKey: 'user_id' });
MessageUsage.belongsTo(User, { foreignKey: 'user_id' });
SupportTicket.belongsTo(User, { foreignKey: 'user_id' });
PasswordResetRequest.belongsTo(User, { foreignKey: 'user_id' });
Notification.belongsTo(User, { foreignKey: 'user_id' });
AdminLog.belongsTo(User, { foreignKey: 'admin_id' });

// ============================================================
// Subscription relations
// ============================================================
Subscription.belongsTo(SubscriptionPlan, { foreignKey: 'plan_id' });
SubscriptionPlan.hasMany(Subscription, { foreignKey: 'plan_id' });

// ============================================================
// WhatsAppBot relations
// ============================================================
WhatsAppBot.hasMany(WhatsAppSession, { foreignKey: 'bot_id' });
WhatsAppSession.belongsTo(WhatsAppBot, { foreignKey: 'bot_id' });
WhatsAppBot.hasOne(DeleteEditTrackingSetting, { foreignKey: 'bot_id' });
DeleteEditTrackingSetting.belongsTo(WhatsAppBot, { foreignKey: 'bot_id' });

// ============================================================
// TelegramBot relations
// ============================================================
TelegramBot.hasMany(TelegramSubscriber, { foreignKey: 'bot_id' });
TelegramSubscriber.belongsTo(TelegramBot, { foreignKey: 'bot_id' });

// ============================================================
// PaymentRequest relations
// ============================================================
PaymentRequest.belongsTo(Subscription, { foreignKey: 'subscription_id' });
Subscription.hasOne(PaymentRequest, { foreignKey: 'subscription_id' });

module.exports = {
    sequelize,
    User,
    Subscription,
    SubscriptionPlan,
    PaymentRequest,
    WhatsAppBot,
    WhatsAppSession,
    TelegramBot,
    TelegramSubscriber,
    ClientWebsite,
    CatalogItem,
    AISetting,
    MessageUsage,
    SupportTicket,
    PasswordResetRequest,
    Notification,
    DeleteEditTrackingSetting,
    AdminLog
};